var searchData=
[
  ['transfermode_0',['TransferMode',['../classsf_1_1Ftp.html#a1cd6b89ad23253f6d97e6d4ca4d558cb',1,'sf::Ftp']]],
  ['type_1',['Type',['../classsf_1_1Shader.html#afaa1aa65e5de37b74d047da9def9f9b3',1,'sf::Shader::Type'],['../classsf_1_1Socket.html#a5d3ff44e56e68f02816bb0fabc34adf8',1,'sf::Socket::Type'],['../classsf_1_1Cursor.html#ab9ab152aec1f8a4955e34ccae08f930a',1,'sf::Cursor::Type'],['../classsf_1_1Sensor.html#a687375af3ab77b818fca73735bcaea84',1,'sf::Sensor::Type']]]
];
